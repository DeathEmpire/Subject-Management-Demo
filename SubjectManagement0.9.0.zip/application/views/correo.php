<?php date_default_timezone_set('America/Santiago');?>
	<div id='header'>
		<img src="<?= base_url('img/icc_logo.png'); ?>" style='width:50px;' /><br />	
	</div>

	<div id='cuerpo'>
		<br />
			<?= $this->load->view($contenido) ?>
		<br />
	</div>

	<div id='footer' style="text-align:right;">
	<br />	
	Asesor�as en Investigaci�n Cl�nica SpA
	<br />
	</div>
