<div>			
	<img src='<?php echo base_url('img/icc_logo.png'); ?>'>
	
</div>