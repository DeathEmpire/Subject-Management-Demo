<div class="page-header">
	<small> Un nuevo password fue enviado a su cuenta de correo electronico registrado en el sistema. </small> </h1>
</div>