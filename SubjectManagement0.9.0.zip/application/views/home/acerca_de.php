<div class="hero-unit">
	<h1> Control de Acceso a Usuarios </h1>
	<hr>
	<p> Sistema de contro de acceso - Versión 1.0 - Desarrollado en PHP CodeIgniter</p>
	<p> <img src="<?= base_url('img/codeigniter.png')?>"> </p>
    <p> Sistema de Control de Accesos a usuarios, donde se pueden crear usuarios, opciones de menú, y administrar las diferentes opciones para los diferentes tipos de usuarios. Página de autentificación. </p>
</div>
