<div class="hero-unit">
	<h1> Acceso Denegado ! </h1>
	<hr>
	<p> El acceso a la pagina solicitada ha sido negado. </p>
	<p> <img src="<?= base_url('img/acceso_denegado.png')?>"> </p>
    <p> Favor de contactar con el administrador del sistema si cree que hay un error. </p>
</div>
